export default {
  data () {
    return {
      api: 'http://101.200.185.137:8080/zhiyin-manager'
    }
  }
}
